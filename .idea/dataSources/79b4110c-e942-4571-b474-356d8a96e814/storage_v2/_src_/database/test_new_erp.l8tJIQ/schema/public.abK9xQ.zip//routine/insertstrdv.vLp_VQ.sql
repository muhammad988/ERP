create function insertstrdv(_sourceid integer, _stageid integer, _sectorid integer, _departmentid integer, _projectid integer, _orgunitid integer, _categoryid integer, _categoryoptionid integer, _dataelementid integer, _focalpointid integer, _userid integer, _value character varying) returns void
    language plpgsql
as
$$
declare _structurebudgetid integer;
BEGIN
                INSERT into structurebudget (sourceid,stageid,sectorid,departmentid,projectid,orgunitid,categoryid,categoryoptionid,dataelementid,focalpointid,userid) 
values(_sourceid,_stageid,_sectorid,_departmentid,_projectid,_orgunitid,_categoryid,_categoryoptionid,_dataelementid,_focalpointid,_userid) RETURNING structurebudgetid into                                          _structurebudgetid;
                insert into datavalue(structureid,value)values(_structurebudgetid,_value);
                
                END;
$$;

alter function insertstrdv(integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, integer, varchar) owner to postgres;

